package com.FT05.CloudCA.service.impl;


public class TestingCoreServiceImpl {
}
