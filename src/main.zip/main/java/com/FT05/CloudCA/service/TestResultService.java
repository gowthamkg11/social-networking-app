package com.FT05.CloudCA.service;

public interface TestResultService {
}
