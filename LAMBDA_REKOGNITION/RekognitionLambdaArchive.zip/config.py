
mysql_config = {
    'host': 'cloudft05.cgjzt35iknje.ap-southeast-1.rds.amazonaws.com',
    'user': 'FT05DB',
    'password': 'instagramclone',
    'db': 'cloudft05',
    'port': 3306
}